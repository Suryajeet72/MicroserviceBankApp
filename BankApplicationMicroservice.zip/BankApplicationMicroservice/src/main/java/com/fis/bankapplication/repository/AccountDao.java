package com.fis.bankapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.fis.bankapplication.model.Account;

public interface AccountDao extends JpaRepository<Account, Long> {

	@Query("Update Account  set accBalance=accBalance+?2 where accNumber=?1")
	 public abstract String depositAccount(long accNumber, double amount);

	@Query("Update Account set accBalance=accBalance - ?2 where accNumber=?1")
	public abstract String withdrawAccount(long accNumber, double amount);

	
	//@Query("Update Account a1 set a1.accBalance=a1.accBalance-?3 where a1.accNumber=?1 and Update Account a2 set a2.accBalance=a2.accBalance+?3 where a2.accNumber=?2")
	//public abstract String FundTransferAccount(long fromAccount,long toAccount,double amount);
	

}
